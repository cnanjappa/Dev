export * from "./EventCard";
export * from "./IEventCardProps";
//# sourceMappingURL=index.d.ts.map