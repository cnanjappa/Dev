declare const styles: {
    cardWrapper: string;
    compactCard: string;
    dateBox: string;
    normalCard: string;
    dateBoxContainer: string;
    category: string;
    emptyStatePreviewContainer: string;
    title: string;
    datetime: string;
    location: string;
    addToMyCalendar: string;
    root: string;
    rootIsCompact: string;
    rootIsActionable: string;
    detailsContainer: string;
};
export default styles;
//# sourceMappingURL=EventCard.module.scss.d.ts.map