/// <reference types="react" />
import { IEventCardProps } from ".";
/**
 * Shows an event in a document card
 */
export declare const EventCard: (props: IEventCardProps) => JSX.Element;
//# sourceMappingURL=EventCard.d.ts.map