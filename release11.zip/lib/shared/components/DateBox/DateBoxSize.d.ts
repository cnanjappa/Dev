export declare enum DateBoxSize {
    Small = 0,
    Medium = 1
}
//# sourceMappingURL=DateBoxSize.d.ts.map