/// <reference types="react" />
import { IDateBoxProps } from ".";
/**
 * Shows a date in a SharePoint-looking date
 */
export declare const DateBox: (props: IDateBoxProps) => JSX.Element;
//# sourceMappingURL=DateBox.d.ts.map