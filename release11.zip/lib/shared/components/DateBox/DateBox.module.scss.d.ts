declare const styles: {
    box: string;
    boxContent: string;
    boxIsSingleDay: string;
    boxIsMultipleDays: string;
    date: string;
    boxIsSmall: string;
    boxIsMedium: string;
    boxIsLarge: string;
    day: string;
    month: string;
    separator: string;
};
export default styles;
//# sourceMappingURL=DateBox.module.scss.d.ts.map