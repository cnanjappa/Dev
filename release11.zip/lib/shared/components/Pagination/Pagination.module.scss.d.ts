declare const styles: {
    Pagination: string;
    next: string;
    prev: string;
    nogo: string;
    noPageNum: string;
};
export default styles;
//# sourceMappingURL=Pagination.module.scss.d.ts.map