declare const styles: {
    centerPadding: string;
    filmstripLayout: string;
    filmStrip: string;
    sliderButtons: string;
    indexButtonContainer: string;
    indexButton: string;
    carouselDotsContainer: string;
    carouselDot: string;
    leftPositioned: string;
    rightPositioned: string;
};
export default styles;
//# sourceMappingURL=FilmstripLayout.module.scss.d.ts.map