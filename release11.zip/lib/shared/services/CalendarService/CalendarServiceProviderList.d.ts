export declare enum CalendarServiceProviderType {
    SharePoint = "SharePoint",
    WordPress = "WordPress",
    Exchange = "Exchange",
    iCal = "iCal",
    RSS = "RSS",
    Mock = "Mock"
}
export declare class CalendarServiceProviderList {
    static getProviders(): any[];
}
//# sourceMappingURL=CalendarServiceProviderList.d.ts.map