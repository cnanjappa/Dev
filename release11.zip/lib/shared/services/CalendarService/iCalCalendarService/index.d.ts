export * from "./iCalCalendarService";
//# sourceMappingURL=index.d.ts.map