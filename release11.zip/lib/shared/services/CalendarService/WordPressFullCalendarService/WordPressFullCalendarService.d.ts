/**
 * ExtensionService
 */
import { ICalendarService } from "..";
import { BaseCalendarService } from "../BaseCalendarService";
import { ICalendarEvent } from "../ICalendarEvent";
export declare class WordPressFullCalendarService extends BaseCalendarService implements ICalendarService {
    constructor();
    getEvents: () => Promise<ICalendarEvent[]>;
}
//# sourceMappingURL=WordPressFullCalendarService.d.ts.map