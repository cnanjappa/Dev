import { HttpClientResponse } from "@microsoft/sp-http";
import { IWebPartContext } from "@microsoft/sp-webpart-base";
import { CalendarEventRange } from ".";
import { ICalendarEvent } from "./ICalendarEvent";
import { ICalendarService } from "./ICalendarService";
/**
 * Base Calendar Service
 * Implements some generic methods that can be used by ICalendarService providers.
 * Each provider can also implement their own ways to retrieve and parse events, if they
 * choose to do so. We won't judge.
 */
export declare abstract class BaseCalendarService implements ICalendarService {
    Context: IWebPartContext;
    FeedUrl: string;
    NavigationUrl: string;
    ArchiveUrl: string;
    EventRange: CalendarEventRange;
    UseCORS: boolean;
    CacheDuration: number;
    Name: string;
    MaxTotal: number;
    ConvertFromUTC: boolean;
    getEvents: () => Promise<ICalendarEvent[]>;
    /**
     * Solves an issue where some providers (I'm looking at you, WordPress) returns all-day events
     * as starting from midight on the first day, and ending at midnight on the second day, making events
     * appear as lasting 2 days when they should last only 1 day
     * @param event The event that needs to be fixed
     */
    protected fixAllDayEvents(events: ICalendarEvent[]): ICalendarEvent[];
    /**
     * Not every provider allows the feed to be filtered. Use this method to filter events after
     * the provider has retrieved them so that we can be consistent regardless of the provider
     * @param events The list of events to filter
     */
    protected filterEventRange(events: ICalendarEvent[]): ICalendarEvent[];
    /**
     * This is a cheesy approach to inject start and end dates from a feed url.
     */
    protected replaceTokens(feedUrl: string, dateRange: CalendarEventRange): string;
    /**
     * Retrieves the response using a CORS proxy or directly, depending on the settings
     * @param feedUrl The URL where to retrieve the events
     */
    protected fetchResponse(feedUrl: string): Promise<HttpClientResponse>;
    /**
     * Returns a URL or a CORS-formatted URL
     * @param feedUrl The URL for the feed
     */
    protected getCORSUrl(feedUrl: string): string;
    /**
     * Retrives the response and returns a JSON object
     * @param feedUrl The URL where to retrieve the events
     */
    protected fetchResponseAsJson(feedUrl: string): Promise<any>;
    /**
     * Converts a value to a date, possibly as a UTC date
     * @param dateValue The date value to convert
     */
    protected convertToDate(dateValue: any): Date;
}
//# sourceMappingURL=BaseCalendarService.d.ts.map