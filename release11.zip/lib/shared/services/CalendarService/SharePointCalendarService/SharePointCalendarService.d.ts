/**
 * ExtensionService
 */
import { ICalendarService } from "..";
import { BaseCalendarService } from "../BaseCalendarService";
import { ICalendarEvent } from "../ICalendarEvent";
export declare class SharePointCalendarService extends BaseCalendarService implements ICalendarService {
    constructor();
    getEvents: () => Promise<ICalendarEvent[]>;
}
//# sourceMappingURL=SharePointCalendarService.d.ts.map