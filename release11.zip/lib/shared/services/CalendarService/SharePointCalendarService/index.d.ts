export * from "./SharePointCalendarService";
//# sourceMappingURL=index.d.ts.map