import { BaseCalendarService } from "../BaseCalendarService";
import { ICalendarEvent } from "../ICalendarEvent";
import { ICalendarService } from "../ICalendarService";
export declare class MockCalendarService extends BaseCalendarService implements ICalendarService {
    constructor();
    getEvents: () => Promise<ICalendarEvent[]>;
}
//# sourceMappingURL=MockCalendarService.d.ts.map