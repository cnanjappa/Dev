import * as React from "react";
import { ICalendarFeedSummaryProps, ICalendarFeedSummaryState } from "./CalendarFeedSummary.types";
/**
 * Displays a feed summary from a given calendar feed provider. Renders a different view for mobile/narrow web parts.
 */
export default class CalendarFeedSummary extends React.Component<ICalendarFeedSummaryProps, ICalendarFeedSummaryState> {
    constructor(props: ICalendarFeedSummaryProps);
    /**
     * When components are mounted, get the events
     */
    componentDidMount(): void;
    /**
     * When someone changes the property pane, it triggers this event. Use it to determine if we need to refresh the events or not
     * @param prevProps The previous props before changes are applied
     * @param prevState The previous state before changes are applied
     */
    componentDidUpdate(prevProps: ICalendarFeedSummaryProps): void;
    /**
     * Renders the view. There can be three different outcomes:
     * 1. Web part isn't configured and we show the placeholders
     * 2. Web part is configured and we're loading events, or
     * 3. Web part is configured and events are loaded
     */
    render(): React.ReactElement<ICalendarFeedSummaryProps>;
    /**
     * Render your web part content
     */
    private _renderContent;
    /**
     * Tries to make sense of the returned error messages and provides
     * (hopefully) helpful guidance on how to fix the issue.
     * It isn't the best piece of coding I've seen. I'm open to suggested improvements
     */
    private _renderError;
    /**
     * Renders a narrow view of the calendar feed when the webpart is less than 480 pixels
     */
    private _renderNarrowList;
    private _onPageUpdate;
    /**
     * Render a normal view for devices that are wider than 480
     */
    private _renderNormalList;
    /**
     * When users click on the Configure button, we display the property pane
     */
    private _onConfigure;
    /**
     * Load events from the cache or, if expired, load from the event provider
     */
    private _loadEvents;
}
//# sourceMappingURL=CalendarFeedSummary.d.ts.map