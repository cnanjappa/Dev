/* tslint:disable */
require("./Pagination.module.css");
const styles = {
  Pagination: 'Pagination_78ddfae3',
  next: 'next_78ddfae3',
  prev: 'prev_78ddfae3',
  nogo: 'nogo_78ddfae3',
  noPageNum: 'noPageNum_78ddfae3'
};

export default styles;
/* tslint:enable */