/* tslint:disable */
require("./EventCard.module.css");
const styles = {
  cardWrapper: 'cardWrapper_7d50a328',
  compactCard: 'compactCard_7d50a328',
  dateBox: 'dateBox_7d50a328',
  normalCard: 'normalCard_7d50a328',
  dateBoxContainer: 'dateBoxContainer_7d50a328',
  category: 'category_7d50a328',
  emptyStatePreviewContainer: 'emptyStatePreviewContainer_7d50a328',
  title: 'title_7d50a328',
  datetime: 'datetime_7d50a328',
  location: 'location_7d50a328',
  addToMyCalendar: 'addToMyCalendar_7d50a328',
  root: 'root_7d50a328',
  rootIsCompact: 'rootIsCompact_7d50a328',
  rootIsActionable: 'rootIsActionable_7d50a328',
  detailsContainer: 'detailsContainer_7d50a328'
};

export default styles;
/* tslint:enable */