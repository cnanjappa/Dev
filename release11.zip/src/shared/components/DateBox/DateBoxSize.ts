export enum DateBoxSize {
  Small,
  Medium
}
