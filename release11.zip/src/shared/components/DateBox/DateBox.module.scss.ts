/* tslint:disable */
require("./DateBox.module.css");
const styles = {
  box: 'box_e708a0d6',
  boxContent: 'boxContent_e708a0d6',
  boxIsSingleDay: 'boxIsSingleDay_e708a0d6',
  boxIsMultipleDays: 'boxIsMultipleDays_e708a0d6',
  date: 'date_e708a0d6',
  boxIsSmall: 'boxIsSmall_e708a0d6',
  boxIsMedium: 'boxIsMedium_e708a0d6',
  boxIsLarge: 'boxIsLarge_e708a0d6',
  day: 'day_e708a0d6',
  month: 'month_e708a0d6',
  separator: 'separator_e708a0d6'
};

export default styles;
/* tslint:enable */