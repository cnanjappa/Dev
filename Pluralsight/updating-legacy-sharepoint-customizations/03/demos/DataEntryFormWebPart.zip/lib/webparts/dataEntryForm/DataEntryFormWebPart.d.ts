import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IDataEntryFormWebPartProps {
    runningListName: string;
}
export default class DataEntryFormWebPart extends BaseClientSideWebPart<IDataEntryFormWebPartProps> {
    render(): void;
    private addEventHandler;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=DataEntryFormWebPart.d.ts.map