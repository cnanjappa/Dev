/* tslint:disable */
require("./DataEntryFormWebPart.module.css");
const styles = {
  dataEntryForm: 'dataEntryForm_0717695d',
  container: 'container_0717695d',
  row: 'row_0717695d',
  column: 'column_0717695d',
  'ms-Grid': 'ms-Grid_0717695d',
  title: 'title_0717695d',
  subTitle: 'subTitle_0717695d',
  description: 'description_0717695d',
  button: 'button_0717695d',
  label: 'label_0717695d'
};

export default styles;
/* tslint:enable */