declare interface IDataEntryFormWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  ListNameFieldLabel: string;
}

declare module 'DataEntryFormWebPartStrings' {
  const strings: IDataEntryFormWebPartStrings;
  export = strings;
}
