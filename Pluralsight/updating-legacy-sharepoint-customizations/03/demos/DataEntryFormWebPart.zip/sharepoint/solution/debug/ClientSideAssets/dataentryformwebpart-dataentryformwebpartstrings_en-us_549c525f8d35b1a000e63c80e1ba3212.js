define([], function() {
  return {
    "PropertyPaneDescription": "Web part to enter miles for the Carved Rock Fitness Running Challenge",
    "BasicGroupName": "Web Part Properties",
    "DescriptionFieldLabel": "Description Field",
    "ListNameFieldLabel": "Name of list in which to store entries"
  }
});