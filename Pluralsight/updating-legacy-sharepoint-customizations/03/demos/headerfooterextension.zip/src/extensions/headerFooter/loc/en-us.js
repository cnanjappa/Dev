define([], function() {
  return {
    "Title": "HeaderFooterApplicationCustomizer"
  }
});