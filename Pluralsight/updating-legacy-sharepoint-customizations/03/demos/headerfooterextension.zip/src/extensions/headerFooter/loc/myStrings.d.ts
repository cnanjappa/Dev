declare interface IHeaderFooterApplicationCustomizerStrings {
  Title: string;
}

declare module 'HeaderFooterApplicationCustomizerStrings' {
  const strings: IHeaderFooterApplicationCustomizerStrings;
  export = strings;
}
