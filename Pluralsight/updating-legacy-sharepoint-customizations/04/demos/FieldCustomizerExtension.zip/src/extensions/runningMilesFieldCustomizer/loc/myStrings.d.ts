declare interface IRunningMilesFieldCustomizerFieldCustomizerStrings {
  Title: string;
}

declare module 'RunningMilesFieldCustomizerFieldCustomizerStrings' {
  const strings: IRunningMilesFieldCustomizerFieldCustomizerStrings;
  export = strings;
}
