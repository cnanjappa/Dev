/* tslint:disable */
require("./RunningMilesFieldCustomizerFieldCustomizer.module.css");
const styles = {
  RunningMilesFieldCustomizer: 'RunningMilesFieldCustomizer_a58f47bc',
  cell: 'cell_a58f47bc'
};

export default styles;
/* tslint:enable */