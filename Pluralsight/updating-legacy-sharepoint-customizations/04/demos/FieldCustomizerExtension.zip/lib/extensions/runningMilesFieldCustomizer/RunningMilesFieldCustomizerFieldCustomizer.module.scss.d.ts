declare const styles: {
    RunningMilesFieldCustomizer: string;
    cell: string;
};
export default styles;
//# sourceMappingURL=RunningMilesFieldCustomizerFieldCustomizer.module.scss.d.ts.map