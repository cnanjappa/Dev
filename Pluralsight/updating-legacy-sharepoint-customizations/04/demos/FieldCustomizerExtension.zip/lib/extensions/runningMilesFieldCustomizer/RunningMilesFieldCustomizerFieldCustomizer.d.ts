import { BaseFieldCustomizer, IFieldCustomizerCellEventParameters } from '@microsoft/sp-listview-extensibility';
/**
 * If your field customizer uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IRunningMilesFieldCustomizerFieldCustomizerProperties {
    sampleText?: string;
}
export default class RunningMilesFieldCustomizerFieldCustomizer extends BaseFieldCustomizer<IRunningMilesFieldCustomizerFieldCustomizerProperties> {
    onInit(): Promise<void>;
    onRenderCell(event: IFieldCustomizerCellEventParameters): void;
    onDisposeCell(event: IFieldCustomizerCellEventParameters): void;
}
//# sourceMappingURL=RunningMilesFieldCustomizerFieldCustomizer.d.ts.map