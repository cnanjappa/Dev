/* tslint:disable */
require("./DateBox.module.css");
const styles = {
  box: 'box_0f0c67e4',
  boxContent: 'boxContent_0f0c67e4',
  boxContentPadding: 'boxContentPadding_0f0c67e4',
  boxIsSingleDay: 'boxIsSingleDay_0f0c67e4',
  boxIsMultipleDays: 'boxIsMultipleDays_0f0c67e4',
  boxIsSmall: 'boxIsSmall_0f0c67e4',
  date: 'date_0f0c67e4',
  boxIsMedium: 'boxIsMedium_0f0c67e4',
  boxIsLarge: 'boxIsLarge_0f0c67e4',
  month: 'month_0f0c67e4',
  day: 'day_0f0c67e4',
  separator: 'separator_0f0c67e4'
};

export default styles;
/* tslint:enable */