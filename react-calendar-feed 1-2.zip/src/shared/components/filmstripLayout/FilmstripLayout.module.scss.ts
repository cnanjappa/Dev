/* tslint:disable */
require("./FilmstripLayout.module.css");
const styles = {
  centerPadding: '50px',
  filmstripLayout: 'filmstripLayout_139ca8bd',
  filmStrip: 'filmStrip_139ca8bd',
  sliderButtons: 'sliderButtons_139ca8bd',
  indexButtonContainer: 'indexButtonContainer_139ca8bd',
  indexButton: 'indexButton_139ca8bd',
  carouselDotsContainer: 'carouselDotsContainer_139ca8bd',
  carouselDot: 'carouselDot_139ca8bd',
  leftPositioned: 'leftPositioned_139ca8bd',
  rightPositioned: 'rightPositioned_139ca8bd'
};

export default styles;
/* tslint:enable */