/* tslint:disable */
require("./CalendarFeedSummary.module.css");
const styles = {
  calendarFeedSummary: 'calendarFeedSummary_24fea2a5',
  webPartChrome: 'webPartChrome_24fea2a5',
  headerSmMargin: 'headerSmMargin_24fea2a5',
  headerLgMargin: 'headerLgMargin_24fea2a5',
  webPartHeader: 'webPartHeader_24fea2a5',
  seeAllSpan: 'seeAllSpan_24fea2a5',
  seeAll: 'seeAll_24fea2a5',
  content: 'content_24fea2a5',
  list: 'list_24fea2a5',
  spinner: 'spinner_24fea2a5',
  emptyMessage: 'emptyMessage_24fea2a5',
  errorMessage: 'errorMessage_24fea2a5',
  moreDetails: 'moreDetails_24fea2a5'
};

export default styles;
/* tslint:enable */