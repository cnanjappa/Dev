declare const styles: {
    calendarFeedSummary: string;
    webPartChrome: string;
    headerSmMargin: string;
    headerLgMargin: string;
    webPartHeader: string;
    seeAllSpan: string;
    seeAll: string;
    content: string;
    list: string;
    spinner: string;
    emptyMessage: string;
    errorMessage: string;
    moreDetails: string;
};
export default styles;
//# sourceMappingURL=CalendarFeedSummary.module.scss.d.ts.map