import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";
import { IPropertyPaneConfiguration } from "@microsoft/sp-property-pane";
import { Version } from '@microsoft/sp-core-library';
import { ICalendarFeedSummaryWebPartProps } from "./CalendarFeedSummaryWebPart.types";
/**
 * Calendar Feed Summary Web Part
 * This web part shows a summary of events, in a film-strip (for normal views) or list view (for narrow views)
 * It is called a summary web part because it doesn't allow the user to filter events.
 */
export default class CalendarFeedSummaryWebPart extends BaseClientSideWebPart<ICalendarFeedSummaryWebPartProps> {
    private _providerList;
    private _themeProvider;
    private _themeVariant;
    constructor();
    protected onInit(): Promise<void>;
    /**
     * Renders the web part
     */
    render(): void;
    /**
     * We're disabling reactive property panes here because we don't want the web part to try to update events as
     * people are typing in the feed URL.
     */
    protected get disableReactivePropertyChanges(): boolean;
    /**
     * Show the configuration pane
     */
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
    /**
     * If we get resized, call the Render method so that we can switch between the narrow view and the regular view
     */
    protected onAfterResize(newWidth: number): void;
    /**
       * Returns the data version
       */
    protected get dataVersion(): Version;
    /**
     * Returns true if the web part is configured and ready to show events. If it returns false, we'll show the configuration placeholder.
     */
    private _isConfigured;
    /**
     * Validates a URL when users type them in the configuration pane.
     * @param feedUrl The URL to validate
     */
    private _validateFeedUrl;
    /**
     * Initialize a feed data provider from the list of existing providers
     */
    private _getDataProvider;
    /**
   * Update the current theme variant reference and re-render.
   *
   * @param args The new theme
   */
    private _handleThemeChangedEvent;
}
//# sourceMappingURL=CalendarFeedSummaryWebPart.d.ts.map