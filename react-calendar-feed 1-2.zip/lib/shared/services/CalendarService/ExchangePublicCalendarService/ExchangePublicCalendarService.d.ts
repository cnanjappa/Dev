/**
 * Exchange Public Calendar Service
 */
import { ICalendarService } from "..";
import { ICalendarEvent } from "../ICalendarEvent";
import { iCalCalendarService } from "../iCalCalendarService";
export declare class ExchangePublicCalendarService extends iCalCalendarService implements ICalendarService {
    constructor();
    getEvents: () => Promise<ICalendarEvent[]>;
}
//# sourceMappingURL=ExchangePublicCalendarService.d.ts.map