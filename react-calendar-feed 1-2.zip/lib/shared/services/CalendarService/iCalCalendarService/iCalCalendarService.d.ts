import { ICalendarService } from "..";
import { BaseCalendarService } from "../BaseCalendarService";
import { ICalendarEvent } from "../ICalendarEvent";
export declare class iCalCalendarService extends BaseCalendarService implements ICalendarService {
    constructor();
    getEvents: () => Promise<ICalendarEvent[]>;
}
//# sourceMappingURL=iCalCalendarService.d.ts.map