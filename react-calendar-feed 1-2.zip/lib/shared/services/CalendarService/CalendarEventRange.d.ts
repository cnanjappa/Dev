export declare enum DateRange {
    OneWeek = 0,
    TwoWeeks = 1,
    Month = 2,
    Quarter = 3,
    Year = 4
}
export declare class CalendarEventRange {
    Start: Date;
    End: Date;
    DateRange: DateRange;
    constructor(range: DateRange);
    private _getRangeEnd;
}
//# sourceMappingURL=CalendarEventRange.d.ts.map