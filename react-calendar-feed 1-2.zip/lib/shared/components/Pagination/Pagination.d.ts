/// <reference types="react" />
import { IPaginationProps } from ".";
/**
 * A custom pagination control designed to look & feel like Office UI Fabric
 */
export declare const Pagination: (props: IPaginationProps) => JSX.Element;
//# sourceMappingURL=Pagination.d.ts.map