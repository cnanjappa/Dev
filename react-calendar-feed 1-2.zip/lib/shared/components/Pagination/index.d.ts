export * from "./Pagination";
export * from "./IPagingProps";
//# sourceMappingURL=index.d.ts.map