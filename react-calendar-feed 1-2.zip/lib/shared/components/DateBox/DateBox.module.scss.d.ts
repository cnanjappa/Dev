declare const styles: {
    box: string;
    boxContent: string;
    boxContentPadding: string;
    boxIsSingleDay: string;
    boxIsMultipleDays: string;
    boxIsSmall: string;
    date: string;
    boxIsMedium: string;
    boxIsLarge: string;
    month: string;
    day: string;
    separator: string;
};
export default styles;
//# sourceMappingURL=DateBox.module.scss.d.ts.map