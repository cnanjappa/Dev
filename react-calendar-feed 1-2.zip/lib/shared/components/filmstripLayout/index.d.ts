export * from "./FilmstripLayout";
//# sourceMappingURL=index.d.ts.map