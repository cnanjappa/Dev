/// <reference types="react" />
import { IReadonlyTheme } from '@microsoft/sp-component-base';
/**
 * Filmstrip layout
 * Presents the child compoments as a slick slide
 */
export declare const FilmstripLayout: (props: {
    children: any;
    clientWidth: number;
    themeVariant?: IReadonlyTheme;
    ariaLabel?: string;
}) => JSX.Element;
//# sourceMappingURL=FilmstripLayout.d.ts.map