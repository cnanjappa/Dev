define([], function() {
  return {
    "SharePointProviderName": "SharePoint Calendar",
    "WordPressProviderName": "WordPress",
    "ExchangeProviderName": "Exchange Public Calendar",
    "iCalProviderName": "iCal",
    "RSSProviderName": "RSS",
    "MockProviderName": "Mock",
  }
});
